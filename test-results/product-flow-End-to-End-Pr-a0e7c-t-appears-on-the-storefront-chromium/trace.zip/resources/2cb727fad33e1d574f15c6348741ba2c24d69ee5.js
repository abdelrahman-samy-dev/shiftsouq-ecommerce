(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_03wny5v._.js","static/chunks/node_modules_lucide-react_dist_esm_icons_0rkuq3h._.js"],
    source: "dynamic"
});
