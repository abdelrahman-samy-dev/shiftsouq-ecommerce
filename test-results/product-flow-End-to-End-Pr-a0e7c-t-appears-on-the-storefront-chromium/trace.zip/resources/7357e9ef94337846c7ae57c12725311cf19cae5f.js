(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0p86ytk._.css","static/chunks/_0nzv7pr._.js","static/chunks/node_modules_next_0yfm5o~._.js","static/chunks/node_modules_framer-motion_dist_es_03co3hq._.js","static/chunks/node_modules_motion-dom_dist_es_0oitghd._.js","static/chunks/node_modules_0hawfca._.js"],
    source: "dynamic"
});
