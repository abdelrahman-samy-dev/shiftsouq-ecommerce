(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/components_04ty4by._.js","static/chunks/node_modules_0~w5~4f._.js"],
    source: "dynamic"
});
