(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/components_04t73dj._.js","static/chunks/node_modules_0r-ama2._.js","static/chunks/node_modules_swiper_09aff0e._.css"],
    source: "dynamic"
});
